﻿版本：1.0
源码在source下面
libs是依赖的类库
bin下面是导出的SWC，您可以只引用SWC完成您的项目开发
test下是两个演示项目